module.exports = {
  name: 'aria2ng',
  script: "serve",
  env: {
    PM2_SERVE_PATH: '.',
    PM2_SERVE_PORT: 9003
  }
}

